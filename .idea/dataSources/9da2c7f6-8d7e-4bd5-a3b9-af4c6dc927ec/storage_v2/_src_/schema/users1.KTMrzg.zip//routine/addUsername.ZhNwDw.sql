create
    definer = root@localhost procedure addUsername(IN newusername varchar(20))
BEGIN
	insert into users set username=newusername;
END;


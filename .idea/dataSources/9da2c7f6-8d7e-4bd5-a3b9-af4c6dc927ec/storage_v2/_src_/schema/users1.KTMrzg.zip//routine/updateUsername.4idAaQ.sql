create
    definer = root@localhost procedure updateUsername(IN originalusername varchar(20), IN newusername varchar(20))
BEGIN
	update users set username=newusername where username=originalusername;
END;


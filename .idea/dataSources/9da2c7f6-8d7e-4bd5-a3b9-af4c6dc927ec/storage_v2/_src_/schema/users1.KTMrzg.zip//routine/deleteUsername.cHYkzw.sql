create
    definer = root@localhost procedure deleteUsername(IN deleteusername varchar(20))
BEGIN
	delete from users where username=deleteusername;
END;

